// pages/index.js
import MyGoogleMap from '../components/map/googlemap';

export default function Home() {
  return (
    <div>
      <h1>Mi Mapa de Google</h1>
      <MyGoogleMap />
    </div>
  );
}